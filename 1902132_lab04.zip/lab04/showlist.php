<!DOCTYPE html>
<html>
	<head>

		<!--Personal Lib-->
		<?php include('aris.php'); ?>
			
		<meta charset="UTF-8">
		<!--Need this line for website to be scalable -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Share Your Travels</title>	

		<link rel="stylesheet" href="lib\bootstrap\css\bootstrap.css">
		<link rel="stylesheet" href="css/main.css">

		<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<script src="lib\bootstrap\js\bootstrap.min.js">
	</script>


	</head>


	<body>
		<?php echo HTML(
		['div', 
			'class' => 'list-group',
			['a', 
				'href' => '#', 
				'class' => 'list-group-item active',
			
				['i', 'class' => 'fa fa-camera', 'Pictures'],
				['span', 'class' => 'float-right badge', '25']
			],
			['a', 
				'href' => '#', 
				'class' => 'list-group-item',
				['i', 'class' => 'fa fa-file', 'Files'],

				['span', 'class' => 'float-right badge', '145']
			],
			['a', 
				'href' => '#', 
				'class' => 'list-group-item',
				['i', 'class' => 'fa fa-music', 'Music'],

				['span', 'class' => 'float-right badge', '50']
			],
			['a', 
				'href' => '#', 
				'class' => 'list-group-item',
				['i', 'class' => 'fa fa-video-camera', 'Videos'],

				['span', 'class' => 'float-right badge', '8']
			]



		]);
		?>	
	</body>
	
</html>