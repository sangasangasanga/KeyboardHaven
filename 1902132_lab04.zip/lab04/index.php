<!DOCTYPE html>
<html>
	<head>

		<!--Personal Lib-->
		<?php include('aris.php'); ?>

		<meta charset="UTF-8">
		<!--Need this line for website to be scalable -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Index</title>	

		<link rel="stylesheet" href="lib\bootstrap\css\bootstrap.css">
		<link rel="stylesheet" href="css/main.css">

		<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<script src="lib\bootstrap\js\bootstrap.min.js"> </script>

		<script src="js\main.js"> </script>


	</head>


	<body>
		<script> printCalculation();</script>	
	</body>
	

	<li>list
		<li>sublist</li>
	</li>

</html>