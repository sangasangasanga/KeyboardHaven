<!DOCTYPE html>
<html>
	<head>

		<!--Personal Lib-->
		<?php include('aris.php'); ?>
			
		<meta charset="UTF-8">
		<!--Need this line for website to be scalable -->
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<title>Share Your Travels</title>	

		<link rel="stylesheet" href="lib\bootstrap\css\bootstrap.css">
		<link rel="stylesheet" href="css/main.css">

		<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

		<script src="lib\bootstrap\js\bootstrap.min.js"></script>
		<script defer src="js\main.js"> </script>
	</script>


	</head>


	<body>
		<!--Header will contain whole page-->
		<header>
		<!-- NavBar -->
		<?php echo HTML(
		['nav', 'class' => 'navbar navbar-expand-lg navbar-dark bg-dark sticky-top', 
			['a',
			 	'class' => 'navbar-brand',
			 	 'Logo'
		 	],
		 	['div', 'id' => 'nav_minimized', 'class' => 'collapse navbar-collapse', 
			 	['ul', 'class' => 'navbar-nav mr-auto', 
					['li', 'class' => 'nav-item',
						['a', 'class' => 'nav-link', 'href' => '#test', 'Home']
					],
					['li', 'class' => 'nav-item',
						['a', 'class' => 'nav-link', 'href' => '#test', 'Description']
					],
					['li', 'class' => 'nav-item',
						['a', 'class' => 'nav-link', 'href' => '#test', 'Related Photos']
					],
					['li', 'class' => 'nav-item',
						['a', 'class' => 'nav-link', 'href' => '#test', 'Reviews']
					]

				],
				['div', 'class' => 'navbar-nav',
					['li', 'class' => 'nav-link',	
						['i', 'class' => 'fa fa-user-circle-o nav-link', 'Login']
					]
				]
			],			
			['button', 
				'class' => 'navbar-toggler collapsed',
				'type' => 'button',
				'data-toggle' => 'collapse',
				'data-target' => '#nav_minimized',
				['span','class' => 'navbar-toggler-icon']
			]
			
		]
		);
		?>


		<?php echo HTML
		(['div', 'class' => 'jumbotron',
			['h1', 'class' => 'introduction text-center', 'Share Your Travels'],
			['h2', 'class' => 'text-center', 'New York - Central Park']
		]);
		?>	

		<!-- Container containing the 3 Details Description, Related photos and Reviews -->
		<?php echo HTML(
		['div',
			'class' => 'container-fluid',
			['div', 
				'class' => 'row', 
				['div',
					'id' => 'desc_col',
					'class' => 'col-md-4 container-fluid',
					['h3', "Description"],			
					['p', 'class' => 'color-grey', "Photo by Randy Connolly"],
					['p',
						['a', 'This photo of Conservatory Pond in '],
						['a' ,'href' => '#central_park', 'Central Park'],
						['a', ' in '],
						['a', 'href' => '#new_york_city', 'New York City'],
						['a', ' was taken on October 22, 2011 with a Canon EOS 30D Camera.']
					],
					['div', 'class' => 'align-center img-hover', 
						['img', 'class' => 'img-fluid border-black img-responsive',  'src' => 'img/central-park.jpg'],
						['figcaption',
							'class' => 'color-grey', 
							'Conservatory Pond in Central Park'
						]
					]
				],
				['div',
					'id' => 'related_photos_col',
					'class' => 'col-md-4',
					['h3', 'Related Photos'],
					['div', 'id' => 'div_container', 
						['a', 'id' => 'img1', 'class' => 'figure-container', 
							['img',  'src' => 'img/related-square1.jpg', 'alt' => 'Square1Image'],
							['span', 'id' => 'big_img1', 'class' => 'img-pop-up',
								['img', 'src' => 'img/related-large1.jpg', 'alt' => '']
							]
						],
						['a', 'id' => 'img2', 'class' => 'figure-container', 
							['img', 'src' => 'img/related-square2.jpg', 'alt' => 'Square2Image'],
							['span', 'id' => 'big_img2', 'class' => 'img-pop-up',
								['img', 'src' => 'img/related-large2.jpg', 'alt' => '']
							]
						],
						['a', 'id' => 'img3', 'class' => 'figure-container', 
							['img', 'src' => 'img/related-square3.jpg', 'alt' => 'Square3Image'],
							['span', 'id' => 'big_img3', 'class' => 'img-pop-up',
								['img', 'src' => 'img/related-large3.jpg', 'alt' => '']
							]
						]
					]
				],
				['div',
					'id' => 'reviews_col',
					'class' => 'col-md-4',
					['h3', 'Reviews'],
					['p', 'class' => 'reviewed-by', 'By Ricardo on September 15, 2012'],
					['p', 'class' => 'reviewed-msg','Easy on the HDR buddy'],
					['p', 'class' => 'reviewed-by', 'By Susan on October 1, 2012'],
					['p', 'class' => 'reviewed-msg', 'I love Central Park']
				]
			]
		]

		); 
		?> 
		

	</body>
	<!--Footer-->
		<?php echo HTML(['footer',
			'class' => 'bg-dark',
			['div', 'class' => 'text-center',
				['a', 'class' => 'text-white', 'href' => 'labPage.php', 'Home'],
				['i', ' | '],
				['a', 'class' => 'text-white', 'href' => '#bodyrowse', 'Browse'],
				['i', ' | '],
				['a', 'class' => 'text-white', 'href' => '#search', 'Search']
			],
			['div', 'id' => 'copyright_text', 'class' => 'text-center',
				['a', 'Copyright © 2014 Share Your Travels']
			]
		]);

		?>
</html>