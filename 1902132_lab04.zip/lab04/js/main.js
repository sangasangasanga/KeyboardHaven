document.addEventListener('DOMContentLoaded', function() {
   // your code here


   function printCalculation() {

		// var div_container = document.getElementById("content");
		// div_container.appendChild(document.createTextNode("TODO write content"));
		var ele = document.createElement("p");	

		document.write("<div>TODO write content</div>");
		for (var i = 0; i < 10; i++) {		
			document.writeln("<div>The cube of " + i + " is " + Math.pow(i,3) + " </div>");
		}

	}


	function addFunction() {
		var node = document.createElement("LI");
		var textnode = document.createTextNode("Water");
		node.appendChild(textnode);
		document.getElementById("menu").appendChild(node);

	}

	function deleteFunction() { 
		var m = document.getElementById("menu");	
		m.removeChild(m.lastChild);


	}

	function addsubFunction() { 
		var parent = document.createElement("UL");
		var node = document.createElement("LI");
		var textnode = document.createTextNode("Ice");
		node.appendChild(textnode);
		parent.appendChild(node);
		// document.getElementById("menu").lastChild.appendChild(parent);
		document.getElementById("menu").lastChild.appendChild(parent);

	}

	// var c = document.querySelector("#div_container");
	// var big_images = c.querySelectorAll(".figure-container");
	// var hover_image;
	// var popup_image;
	// for (var i = 0; i < big_images.length; i++) {
	// 	//1 is normal image to hover
	// 	//3 is popup
	// 	hover_image = big_images[i].childNodes[1];
	// 	popup_image = big_images[i].childNodes[3];
	// 	hover_image.addEventListener("mouseover", function(e) {
	// 		hover_image.style.visibility = "visible" ;
	// 		hover_image.style.position = "absolute";
	// 		hover_image.style.top ="100px";
	// 		hover_image.style.top = "100px";
	// 		hover_image.style.left = "100px";
	// 		hover_image.style.opacity = " 1.0";
	// 	});

	// 	hover_image.addEventListener("mouseout", function(e) {
	// 		hover_image.style.padding = "10px";
	// 		hover_image.style.background = "#fff";
	// 		hover_image.style.position = "absolute";
	// 		hover_image.style.boxshadow = "0 0 15px #A9A9A9";
	// 		hover_image.style.visibility = "hidden";
	// 	});
	// }

	function applyPopupStyle(e) {
		e.style.visibility = "visible" ;
		e.style.position = "absolute";
		e.style.top ="100px";
		e.style.top = "100px";
		e.style.left = "100px";
		e.style.opacity = " 1.0";
	}

	function applyRemovePopupStyle(e) { 
		e.style.padding = "10px";
		e.style.background =" #fff";
		e.style.position = "absolute";
		e.style.boxshadow = "0 0 15px #A9A9A9";
		e.style.visibility = "hidden";
	}

	document.getElementById("img1").addEventListener("mouseover", function(e) {
		// alert(document.getElementById(this.id).childNodes[1]);
		var e = document.getElementById("big_img1");
		applyPopupStyle(e);
	});
	document.getElementById("img1").addEventListener("mouseout", function(e) {
		var e = document.getElementById("big_img1");
		applyRemovePopupStyle(e);
	});

	document.getElementById("img2").addEventListener("mouseover", function(e) {
		// alert(document.getElementById(this.id).childNodes[1]);
		var e = document.getElementById("big_img2");
		applyPopupStyle(e);
	});
	document.getElementById("img2").addEventListener("mouseout", function(e) {
		var e = document.getElementById("big_img2");
		applyRemovePopupStyle(e);
	});

	document.getElementById("img3").addEventListener("mouseover", function(e) {
		// alert(document.getElementById(this.id).childNodes[1]);
		var e = document.getElementById("big_img3");
		applyPopupStyle(e);
	});
	document.getElementById("img3").addEventListener("mouseout", function(e) {
		var e = document.getElementById("big_img3");
		applyRemovePopupStyle(e);
	});


	// .addEventListener("onmouseover", showBiggerPicture);
}, false);



